import styles from "./AddContainer.module.css";
import DropDown from "./DropDown";
import InputField from "./InputField";
import IconButton from "../Buttons/IconButton";
import { FiCheckCircle, FiCornerUpLeft } from "react-icons/fi";
import { useContext, useState } from "react";
import Context from "../App/Context";
function AddContainer() {
  const { set, setData, data, add } = useContext(Context);
  const [task, setTask] = useState("");
  const [time, setTime] = useState("morning");
  function addTask() {
    switch (time) {
      case "morning":
        console.log(time + ": " + task);
        console.log(data);
        add(time, task);
        break;
    }
  }
  return (
    <>
      <div className={styles.cont}>
        <div className={styles.upperCont}>
          <InputField holder={"Enter a task..."} setT={setTask} t={task} />
          <DropDown setT={setTime} t={time} />
        </div>
        <div className={styles.lowerCont}>
          <div className={styles.Btn}>
            <IconButton icon={<FiCornerUpLeft />} set={set} />
          </div>
          <div className={styles.Btn}>
            <IconButton icon={<FiCheckCircle />} func={addTask} set={set} />
          </div>
        </div>
      </div>
    </>
  );
}
export default AddContainer;
